﻿using System;

namespace Class_Composition
{
    class Program
    {
        static void Main(string[] args)
        {
            var animalObj = new Animal();
            var dogObj = new Dog(animalObj);

            var aquaticObj = new Aquatic();
            var fishObj = new Fish(aquaticObj);

            dogObj.Walk();
            fishObj.CanSwim();
        }
    }
}
