﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Composition
{
    class Dog
    {
        // Declare a variable called "_husky" of Data Type "Animal"
        // "Animal" is a class we created and we are setting "_husky" to be of it's Data Type
        // Doing this allows "_husky" to be declared as an object later in the code. 
        private Animal _husky;

        // Create a constructor requiring an object of Data Type Animal
        // This will ensure that the parameter passed in is of the same data type. 
        public Dog(Animal obj)
        {
            // "obj" is set equal to "animalObj" which is an object of the Animal Class
            // Sets "_husky" to be equal to "obj" which allows us to use "_husky" as an object of the Animal Class
            _husky = obj;
        }

        public void Walk()
        {
            _husky.Walk();
        }


    }
}
