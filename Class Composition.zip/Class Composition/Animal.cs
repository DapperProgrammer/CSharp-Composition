﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Composition
{
    class Animal
    {
        private int _weight;
        private string _skinType;

        // Default Constructor
        public Animal()
        { 
            
        }

        public void Walk()
        {
            Console.WriteLine("Walk.");
        }

    }
}
