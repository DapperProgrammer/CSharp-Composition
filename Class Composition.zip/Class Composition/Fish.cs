﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Composition
{
    class Fish
    {
        // Declare a variable called "_swordFish" of Data Type "Aquatic"
        // "Aquatic" is a class we created and we are setting "_swordFish" to be of it's Data Type
        // Doing this allows "_swordFish" to be declared as an object later in the code. 
        private Aquatic _swordFish;

        // Set "obj" to Data Type "Aquatic"
        // This ensures what is passed into the "obj" parameter is also of Data Type "Aquatic"
        public Fish(Aquatic obj)
        {
            // "_swordFish" is set equal to "obj"
            // "_swordFish" inherits all of the functionality of the "Aquatic" Object ("aquaticObj" in Program.cs) just as a child does from its parent
            _swordFish = obj;
        }

        // Allows "_swordFish" to use methods from the Aquatic Class since it has inherited all of its fields and methods from
        // the "aquaticObject" which was passed into the "obj" parameter.
        // Any time you want to use methods from the "Aquatic" class, you must use the "_swordFish" object variable.
        public void CanSwim()
        {
            _swordFish.Swim();
        }

    }
}
